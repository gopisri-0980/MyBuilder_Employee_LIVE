import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { Http, RequestOptions, Headers } from '@angular/http';
import { CommonComponent } from 'src/app/common/common.component';
import { FormGroup, FormControl, Validators, ValidatorFn, AbstractControl, FormBuilder } from "@angular/forms";
declare const $: any;
declare const swal: any;
var temp_refId;
@Component({
  selector: 'app-referefriendsearch',
  templateUrl: './referefriendsearch.component.html',
  styleUrls: ['./referefriendsearch.component.sass']
})
export class ReferefriendsearchComponent implements OnInit {
  Customer_Flat_No: any;
  project_name: any;
  Customer_Name: any;
  Referrar_Id: any;
  Referrar_Name: any;
  referralData: any;
  myflat_booking_id: any;
  fg: FormGroup;
  constructor(public route: ActivatedRoute, private router: Router, 
     public cmn: CommonComponent , private http: Http, private formBuilder: FormBuilder,) {
    sessionStorage.setItem('fromviewpagepredefined', null)
    $('.page-loader-wrapper').hide();
    if (sessionStorage.getItem("backbuttonStatus") == "true") {
      $(function () {
        $("#Refer_Id").val(sessionStorage.getItem("reference_Id"))
        $("#Refer_Name").val(sessionStorage.getItem("referee_name"))
        $("#customerName").val(sessionStorage.getItem("customer_name"))
        $("#Cust_Flat_No").val(sessionStorage.getItem("customer_flatno"))
        $("#projectID").val(sessionStorage.getItem("project_ID"))
      })

      this.SearchRefferalFriend_backbutton(sessionStorage.getItem("reference_Id"), sessionStorage.getItem("referee_name"), sessionStorage.getItem("flatbookId"), sessionStorage.getItem("customer_flatno"), sessionStorage.getItem("project_ID"))
    }


    this.loadSiteNames();


  }
  ngOnInit() {

    this.fg = new FormGroup(
      {
        from: new FormControl(""),
        to: new FormControl("")
      },
      [Validators.required, this.dateRangeValidator]
    );


    $(function () {
      $("#projectID").select2({
        placeholder: "Search Project",
        dir: "ltl",

      });
    });
    $("#projectID").change(function () {
      $(".closeIcon").show();
    });
  }

  private dateRangeValidator: ValidatorFn = (): {
    [key: string]: any;
  } | null => {
    let invalid = false;
    const from = this.fg && this.fg.get("from").value;
    const to = this.fg && this.fg.get("to").value;
    if (from && to) {
      invalid = new Date(from).valueOf() > new Date(to).valueOf();
    }
    return invalid ? { invalidRange: { from, to } } : null;
  };

  loadSiteNames() {
    let url = this.cmn.commonUrl + "site/allSites.spring";

    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    var body = {
      "sessionKey": sessionStorage.getItem("login_sessionkey")

    }

    this.http.post(url, body, options).map(res => res.json()).subscribe(resp => {

      if (resp.responseCode == 200) {
        sessionStorage.setItem("siteNames", JSON.stringify(resp.responseObjList));
        var siteNames = "<option value=''>--Select--</option>";
        for (var i = 0; i < resp.responseObjList.length; i++) {
          siteNames += "<option value='" + resp.responseObjList[i].id + "'>" + resp.responseObjList[i].name + "</option>";
        }
        $('#projectID').html(siteNames);
        $("#projectID").val(sessionStorage.getItem("project_ID"))
      } else if (resp.responseCode == 440) {
        sessionStorage.clear();
        swal("Your Session has been Timed Out!", "Please login once again.", "error");
        this.router.navigate([""]);
      } else {
        $('.page-loader-wrapper').hide();
        swal(resp.errors[0]);
        return false;
      }

    },
      error => {
        $('.page-loader-wrapper').hide();
        var error = JSON.parse(error._body).responseCode;
        if (error == 440) {
          sessionStorage.clear();
          swal("Your Session has been Timed Out!", "Please login once again.", "error");
          this.router.navigate([""]);
        }
      });
  }

  SearchRefferalFriend(condition) {

   
   

    var refferId = $("#Refer_Id").val();
    var refferName = $("#Refer_Name").val();
    var customerName = $("#customerName").val();
    var customerFlat = $("#Cust_Flat_No").val();
    var siteName = $("#projectID").val();
    var fromdate  =  $("#fromDate").val();
    var todate =  $("#toDate").val();

    console.log(fromdate);
    console.log(todate);



    if (condition == 'true') {
      if (refferId == '' && refferName == '' && customerName == '' && customerFlat == '' && siteName == '' && fromdate == '' && todate == '') {
        swal("Please enter any one.");
        return false;
      }
      if ((refferId != '' || refferName != '' || customerName != '' || customerFlat != '' || fromdate == '' || todate == '') && siteName != '' ) {
        swal("Please select project or enter reference data.");
        return false;
      }

      if ($("#referenceId").val() == '' && $("#refereeName").val() == '' && $("#flatbookingId").val() == '' && $("#customerFlatNo").val() == '' && $("#projectID").val() == '' && $("#fromDate").val() =='' && $("#toDate").val() =='') {
        swal("Please select from auto completion suggestions.");
        $("#Refer_Id").val("");
        $("#Refer_Name").val("");
        $("#customerName").val("");
        $("#Cust_Flat_No").val("");
        $("#fromDate").val("");
        $("#toDate").val("");
        return false;
      }
    }


    $('.page-loader-wrapper').show();
    let url = this.cmn.commonUrl + "references/referedCustomers.spring";
    console.log("url :" + url);
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    var body;



    if (condition == 'true') {
      body = {
        "referrerName": $("#refereeName").val(),
        "refrenceId": $("#referenceId").val(),
        "custId": $("#flatbookingId").val(),
        "customerFlatNo": $("#customerFlatNo").val(),
        "siteId": $("#projectID").val(),
        "sessionKey": "" + sessionStorage.getItem("login_sessionkey")
      }
    } else {
      body = {
        "sessionKey": "" + sessionStorage.getItem("login_sessionkey")
      }
    }

    this.http.post(url, body, options).map(res => res.json()).subscribe(resp => {
      $('.page-loader-wrapper').hide();

      if (resp.responseCode == 200) {

        this.referralData = resp.responseObjList.referedCustomer;

        sessionStorage.setItem("referee_name", $("#refereeName").val())
        sessionStorage.setItem("reference_Id", $("#referenceId").val())
        sessionStorage.setItem("flatbookId", $("#flatbookingId").val())
        sessionStorage.setItem("customer_flatno", $("#customerFlatNo").val())
        sessionStorage.setItem("customer_name", $("#customerName").val())
        sessionStorage.setItem("project_ID", $("#projectID").val())
        sessionStorage.setItem("backbuttonStatus", 'true')
        sessionStorage.setItem("refferalData", JSON.stringify(this.referralData));
        setTimeout(function () {
          $(document).ready(function () {
            $('#tableExport').DataTable({
              pageLength: 5,
              lengthMenu: [[5, 10, 20, -1], [5, 10, 20, 'Todos']],
              dom: 'Bfrltip',
              buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
              ],
              retrieve: true,
              "scrollY": true,
              "scrollCollapse": true,
              "scrollX": true,
              "autoWidth": false,
              "iCookieDuration": 60,
              "bStateSave": true,
              "fnStateSave": function (oSettings, oData) {
                localStorage.setItem('offersDataTables', JSON.stringify(oData));
              },
              "fnStateLoad": function (oSettings) {
                return JSON.parse(localStorage.getItem('offersDataTables'));
              }

            });
          });
        }, 2000)

      } else if (resp.responseCode == 440) {
        sessionStorage.clear();
        swal("Your Session has been Timed Out!", "Please login once again.", "error");
        this.router.navigate([""]);
      } else {
        $('.page-loader-wrapper').hide();
        swal(resp.errors[0]);
        return false;
      }
    },
      error => {
        $('.page-loader-wrapper').hide();
        var error = JSON.parse(error._body).responseCode;
        if (error == 440) {
          sessionStorage.clear();
          swal("Your Session has been Timed Out!", "Please login once again.", "error");
          this.router.navigate([""]);
        }
      });
  }



  searchCustomer(e) {
    let url = this.cmn.commonUrl + "references/searchCustomer.spring";
    $("#customerId").val('');

    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    var body = {
      "customerName": e.target.value,
      "sessionKey": "" + sessionStorage.getItem("login_sessionkey")
    }

    this.http.post(url, body, options).map(res => res.json()).subscribe(resp => {

      if (resp.responseCode == 200) {

        var customerData = [];
        for (var i = 0; i < resp.responseObjList.referedCustomer.length; i++) {

          customerData.push({
            "value": resp.responseObjList.referedCustomer[i].custId,
            "label": resp.responseObjList.referedCustomer[i].customerName
          });
        }

        $("#customerName").autocomplete({
          source: customerData,
          delay: 300,
          select: function (event, ui) {

            event.preventDefault();
            $("#customerName").val(ui.item.label);
            $("#flatbookingId").val(ui.item.value);
            sessionStorage.setItem("previouspageId", ui.item.value);
          }
        });
      } else if (resp.responseCode == 440) {
        sessionStorage.clear();
        swal("Your Session has been Timed Out!", "Please login once again.", "error");
        this.router.navigate([""]);
      } else {
        $('.page-loader-wrapper').hide();
        swal(resp.errors[0]);
        return false;
      }
    },
      error => {
        $('.page-loader-wrapper').hide();
        var error = JSON.parse(error._body).responseCode;
        if (error == 440) {
          sessionStorage.clear();
          swal("Your Session has been Timed Out!", "Please login once again.", "error");
          this.router.navigate([""]);
        }
      });
  }

  searchReferenceId(e) {
    let url = this.cmn.commonUrl + "references/searchCustomer.spring";
    $("#referenceId").val('');

    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    var body = {
      "refrenceId": e.target.value,
      "sessionKey": "" + sessionStorage.getItem("login_sessionkey")
    }

    this.http.post(url, body, options).map(res => res.json()).subscribe(resp => {

      if (resp.responseCode == 200) {
        var customerData = [];
        for (var i = 0; i < resp.responseObjList.referedCustomer.length; i++) {

          customerData.push(resp.responseObjList.referedCustomer[i].refrenceId);
        }

        $("#Refer_Id").autocomplete({
          source: customerData,
          delay: 300,
          select: function (event, ui) {

            event.preventDefault();
            $("#Refer_Id").val(ui.item.label);
            $("#referenceId").val(ui.item.value);
            sessionStorage.setItem("previouspageId", ui.item.value);
          }
        });
      } else if (resp.responseCode == 440) {
        sessionStorage.clear();
        swal("Your Session has been Timed Out!", "Please login once again.", "error");
        this.router.navigate([""]);
      } else {
        $('.page-loader-wrapper').hide();
        swal(resp.errors[0]);
        return false;
      }
    },
      error => {
        $('.page-loader-wrapper').hide();
        var error = JSON.parse(error._body).responseCode;
        if (error == 440) {
          sessionStorage.clear();
          swal("Your Session has been Timed Out!", "Please login once again.", "error");
          this.router.navigate([""]);
        }
      });
  }

  searchRefereeName(e) {
    let url = this.cmn.commonUrl + "references/searchCustomer.spring";
    $("#refereeName").val('');

    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    var body = {
      "referrerName": e.target.value,
      "sessionKey": "" + sessionStorage.getItem("login_sessionkey")
    }

    this.http.post(url, body, options).map(res => res.json()).subscribe(resp => {

      if (resp.responseCode == 200) {
        var customerData = [];
        for (var i = 0; i < resp.responseObjList.referedCustomer.length; i++) {

          customerData.push(resp.responseObjList.referedCustomer[i].referrerName);
        }

        $("#Refer_Name").autocomplete({
          source: customerData,
          delay: 300,
          select: function (event, ui) {

            event.preventDefault();
            $("#Refer_Name").val(ui.item.label);
            $("#refereeName").val(ui.item.value);
            sessionStorage.setItem("previouspageId", ui.item.value);
          }
        });
      } else if (resp.responseCode == 440) {
        sessionStorage.clear();
        swal("Your Session has been Timed Out!", "Please login once again.", "error");
        this.router.navigate([""]);
      } else {
        $('.page-loader-wrapper').hide();
        swal(resp.errors[0]);
        return false;
      }
    },
      error => {
        $('.page-loader-wrapper').hide();
        var error = JSON.parse(error._body).responseCode;
        if (error == 440) {
          sessionStorage.clear();
          swal("Your Session has been Timed Out!", "Please login once again.", "error");
          this.router.navigate([""]);
        }
      });
  }

  searchCustomerFlatno(e) {
    let url = this.cmn.commonUrl + "references/searchCustomer.spring";
    $("#customerFlatNo").val('');

    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    var body = {
      "customerFlatNo": e.target.value,
      "sessionKey": "" + sessionStorage.getItem("login_sessionkey")
    }

    this.http.post(url, body, options).map(res => res.json()).subscribe(resp => {

      if (resp.responseCode == 200) {
        var customerData = [];
        for (var i = 0; i < resp.responseObjList.referedCustomer.length; i++) {


          customerData.push({
            "value": resp.responseObjList.referedCustomer[i].customerFlatNo,
            "label": resp.responseObjList.referedCustomer[i].siteNameCustomerFlatNo
          });
        }

        $("#Cust_Flat_No").autocomplete({
          source: customerData,
          delay: 300,
          select: function (event, ui) {

            event.preventDefault();
            $("#Cust_Flat_No").val(ui.item.label);
            $("#customerFlatNo").val(ui.item.value);
            sessionStorage.setItem("previouspageId", ui.item.value);
          }
        });
      } else if (resp.responseCode == 440) {
        sessionStorage.clear();
        swal("Your Session has been Timed Out!", "Please login once again.", "error");
        this.router.navigate([""]);
      } else {
        $('.page-loader-wrapper').hide();
        swal(resp.errors[0]);
        return false;
      }
    },
      error => {
        $('.page-loader-wrapper').hide();
        var error = JSON.parse(error._body).responseCode;
        if (error == 440) {
          sessionStorage.clear();
          swal("Your Session has been Timed Out!", "Please login once again.", "error");
          this.router.navigate([""]);
        }
      });
  }

  clearSiteName() {
    $("#projectID option[value]").remove();
    var sitenamesFromSession = JSON.parse(sessionStorage.getItem("siteNames"));
    var siteNames = "<option value=''>--Select--</option>";
    for (var i = 0; i < sitenamesFromSession.length; i++) {
      siteNames += "<option value='" + sitenamesFromSession[i].id + "'>" + sitenamesFromSession[i].name + "</option>";
    }
    $('#projectID').html(siteNames);
    $(".closeIcon").hide();
  }
  homeClick() {
    this.cmn.commonHomeNavigation();
  }

  viewReferenceData(data) {

    sessionStorage.setItem("refferalData1", JSON.stringify(data));
    this.router.navigate(["view-refer-data"]);
  }


  SearchRefferalFriend_backbutton(reference_Id, referee_name, flatbookId, customer_flatno, project_ID) {


    $('.page-loader-wrapper').show();
    let url = this.cmn.commonUrl + "references/referedCustomers.spring";

    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    var body;



    body = {
      "referrerName": referee_name,
      "refrenceId": reference_Id,
      "custId": flatbookId,

      "customerFlatNo": customer_flatno,
      "siteId": project_ID,
      "sessionKey": "" + sessionStorage.getItem("login_sessionkey")
    }

    this.http.post(url, body, options).map(res => res.json()).subscribe(resp => {
      $('.page-loader-wrapper').hide();

      if (resp.responseCode == 200) {

        this.referralData = resp.responseObjList.referedCustomer;
        sessionStorage.setItem("referee_name", $("#refereeName").val())
        sessionStorage.setItem("reference_Id", $("#referenceId").val())
        sessionStorage.setItem("flatbookId", $("#flatbookingId").val())
        sessionStorage.setItem("customer_flatno", $("#customerFlatNo").val())
        sessionStorage.setItem("project_ID", $("#projectID").val())
        sessionStorage.setItem("backbuttonStatus", 'true')
        sessionStorage.setItem("refferalData", JSON.stringify(this.referralData));
        setTimeout(function () {
          $(document).ready(function () {
            $('#tableExport').DataTable({
              pageLength: 5,
              lengthMenu: [[5, 10, 20, -1], [5, 10, 20, 'Todos']],
              dom: 'Bfrltip',
              buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
              ],
              retrieve: true,
              "scrollY": true,
              "scrollCollapse": true,
              "scrollX": true,
              "autoWidth": false,
              "iCookieDuration": 60,
              "bStateSave": true,
              "fnStateSave": function (oSettings, oData) {
                localStorage.setItem('offersDataTables', JSON.stringify(oData));
              },
              "fnStateLoad": function (oSettings) {
                return JSON.parse(localStorage.getItem('offersDataTables'));
              }

            });
          });
        }, 2000)

      } else if (resp.responseCode == 440) {
        sessionStorage.clear();
        swal("Your Session has been Timed Out!", "Please login once again.", "error");
        this.router.navigate([""]);
      } else {
        $('.page-loader-wrapper').hide();
        swal(resp.errors[0]);
        return false;
      }
    },
      error => {
        $('.page-loader-wrapper').hide();
        var error = JSON.parse(error._body).responseCode;
        if (error == 440) {
          sessionStorage.clear();
          swal("Your Session has been Timed Out!", "Please login once again.", "error");
          this.router.navigate([""]);
        }
      });
  }

  startdatefun() {
    $("#fromDate").val("");
  }

  endtimefun() {
    $("#toDate").val("");
  }
}
